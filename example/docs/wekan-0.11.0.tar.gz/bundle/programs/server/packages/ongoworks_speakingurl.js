(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var getSlug;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/ongoworks_speakingurl/packages/ongoworks_speakingurl.js       //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/ongoworks:speakingurl/speakingurl.js                     //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
getSlug = Npm.require('speakingurl');                                // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['ongoworks:speakingurl'] = {}, {
  getSlug: getSlug
});

})();

//# sourceMappingURL=ongoworks_speakingurl.js.map
